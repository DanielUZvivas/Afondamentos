# Prueba Guiada GIT
#### Primero creamos la carpeta
![alt text](image-1.png)
#### luego hacemos un cd a la carpeta creada anteriormente 
![alt text](image-2.png)
#### Ahora creamos los 2 archivos y hacemos un ls para saber si se crearon correctamente 
![alt text](image-3.png)
#### Posteriormente le meteremos texto haciendole un nano individual a cada uno
#### Y ahora le damos funcionalidad y lo probamos
![alt text](image-4.png)
#### Creamos un nuevo repositorio dentro del actual 
![alt text](image-5.png)
#### Vemos el status 
![alt text](image-6.png)
#### Lo cambiamos del master al main 
![alt text](image-8.png)
#### Y de nuevo volvemos al master
![alt text](image-9.png)
#### Ahora vamos a añadir un archivo y luego confirmamos
![alt text](image-11.png)
#### Hacemos un commit para establecer una version 
![alt text](image-12.png)
#### si fueran muchos cambios podriamos hacer el git commit -F mensaje.txt
#### Ahora hacemos lo mismo que con el script con el texto 
![alt text](image-13.png)
#### Ahora modificamos el texto y vemos que indica que no hay cambios agregados al comit 
![alt text](image-14.png)
#### para el siguiente commit añadieremos un nuevo add
![alt text](image-15.png)
#### ahora hacemos un commit 
![alt text](image-16.png)
#### y el status nos saldra esto
![alt text](image-17.png)
#### Con este comando podemos ver la inforamcion de la ultima version confirmada
![alt text](image-18.png)
#### Y con git log podremos ver todos los commits que hicimos la confirmacion ..
![alt text](image-19.png)
#### con git diff vemos cual es el formato 
![alt text](image-20.png)
![alt text](image-21.png)
#### Ahora si añadimos una nueva linea nos sale el nombre con un + delante y en verde 
![alt text](image-22.png)
#### Creamos el archivo
![alt text](image-23.png)
#### Y creamos hola
![alt text](image-24.png)
#### Nos quedaria algo asi
![alt text](image-25.png)
#### Y una vez que compruebo que funciona creo importante y temporal y nos queda tal que asi
![alt text](image-26.png)
#### A continuacion hacemos lo siguiente
![alt text](image-27.png)
![alt text](image-28.png)
#### y con el tree vemos los archivos que tenemos 
![alt text](image-29.png)
#### Cogemos un tag que nos salga a nosotros y hacemos el show y nos sale toda esta informacion
![alt text](image-30.png)
#### Creamos un tag de una version anterior (tambien se puede hacer git show v0.3)
![alt text](image-31.png)
![alt text](image-32.png)
#### Creamos una rama
![alt text](image-33.png)
![alt text](image-34.png)
#### Cambiamos a la rama de prueba 
![alt text](image-35.png)
![alt text](image-36.png)
#### Hacemos el commit 
![alt text](image-37.png)
#### Modificamos el hola.java
![alt text](image-38.png)
#### Y hacemos el commit correspondiente 
![alt text](image-39.png)
#### Hacemos el comit y lo podemos ver
![alt text](image-40.png)
#### Y ahora vamos a ver si sigue en la version prueba
![alt text](image-41.png)
#### Eliminamos importante 
![alt text](image-42.png)
#### Y ahora creamos el commit
![alt text](image-43.png)
#### Si habia algun archivo en seguimiento y lo quieres quitar puedes hacer esto 
![alt text](image-44.png)
#### Ahora subimos esto a github
![alt text](image-45.png)
#### Pasamos primero el repositorio a main y luego ya nos deja enlazarlo 
![alt text](image-46.png)
![alt text](image-47.png)
#### Para terminar hacemos este comando para subir todos los archivos
![alt text](image-48.png)
#### Y ya nos quedaria tal que asi
![alt text](image-49.png)
